using System;

namespace SingleInheritance
{
    class Vehicle
    {
        public void Start() { Console.WriteLine("Vehicle started."); }
    }

    class Car : Vehicle
    {
        public void Drive() { Console.WriteLine("Car is driving."); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Start();
            car.Drive();
            Console.ReadLine();
        }
    }
}
