SingleInheritance

C# program demonstrating single inheritance using a base class and a derived class.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
