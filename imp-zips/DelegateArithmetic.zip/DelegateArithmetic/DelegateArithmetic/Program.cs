using System;

namespace DelegateArithmetic
{
    public delegate int Calculation(int a, int b);

    class Program
    {
        static int Add(int a, int b) { return a + b; }
        static int Subtract(int a, int b) { return a - b; }
        static int Multiply(int a, int b) { return a * b; }
        static int Divide(int a, int b) { return a / b; }

        static void Main(string[] args)
        {
            Calculation add = Add;
            Calculation subtract = Subtract;
            Calculation multiply = Multiply;
            Calculation divide = Divide;
            Console.WriteLine("Add: " + add(20, 10));
            Console.WriteLine("Subtract: " + subtract(20, 10));
            Console.WriteLine("Multiply: " + multiply(20, 10));
            Console.WriteLine("Divide: " + divide(20, 10));
            Console.ReadLine();
        }
    }
}
