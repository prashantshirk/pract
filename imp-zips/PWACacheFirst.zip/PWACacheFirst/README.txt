PWACacheFirst

Progressive Web Application that supports offline functionality using a Service Worker and the cache-first caching strategy.

How to open:
Open this folder in Visual Studio Code (File > Open Folder), then open index.html in a browser, or use the Live Server extension. The Service Worker needs to be served over localhost or https to install.
