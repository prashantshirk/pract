const CACHE_NAME = 'cache-first-v1';
const urlsToCache = ['index.html', 'style.css', 'app.js', 'manifest.json'];
self.addEventListener('install', event => {
    event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)));
});
self.addEventListener('fetch', event => {
    // Cache-first: serve from cache if present, otherwise go to the network
    event.respondWith(caches.match(event.request).then(response => response || fetch(event.request)));
});
