PWAStudentCRUDOffline

PWA to add, view, update and delete student records, stored locally so details remain accessible offline.

How to open:
Open this folder in Visual Studio Code (File > Open Folder), then open index.html in a browser, or use the Live Server extension. The Service Worker needs to be served over localhost or https to install.
