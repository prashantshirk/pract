if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register('service-worker.js');
    });
}

const form = document.getElementById('studentForm');
const list = document.getElementById('studentList');
function loadStudents() {
    const students = JSON.parse(localStorage.getItem('students') || '[]');
    list.innerHTML = '';
    students.forEach((student, index) => {
        const item = document.createElement('li');
        item.textContent = student.name + ' - ' + student.course + ' ';
        const edit = document.createElement('button');
        edit.textContent = 'Edit';
        edit.onclick = () => {
            const name = prompt('New name', student.name);
            const course = prompt('New course', student.course);
            if (name && course) { students[index] = { name, course }; save(students); }
        };
        const del = document.createElement('button');
        del.textContent = 'Delete';
        del.onclick = () => { students.splice(index, 1); save(students); };
        item.appendChild(edit); item.appendChild(del); list.appendChild(item);
    });
}
function save(students) { localStorage.setItem('students', JSON.stringify(students)); loadStudents(); }
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const students = JSON.parse(localStorage.getItem('students') || '[]');
    students.push({ name: document.getElementById('name').value, course: document.getElementById('course').value });
    save(students); form.reset();
});
loadStudents();
