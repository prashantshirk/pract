using System;

namespace ConstructorOverloading
{
    class Student
    {
        public int Id;
        public string Name;
        public int Age;

        public Student()
        {
            Id = 0; Name = "Unknown"; Age = 0;
            Console.WriteLine("Default constructor called");
        }

        public Student(int id, string name)
        {
            Id = id; Name = name;
            Console.WriteLine("Constructor with id and name called");
        }

        public Student(int id, string name, int age)
        {
            Id = id; Name = name; Age = age;
            Console.WriteLine("Constructor with id, name and age called");
        }

        public void Display()
        {
            Console.WriteLine("Id: " + Id + ", Name: " + Name + ", Age: " + Age);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            Student s2 = new Student(1, "Prashant");
            Student s3 = new Student(2, "Sahil", 20);
            s1.Display(); s2.Display(); s3.Display();
            Console.ReadLine();
        }
    }
}
