ManifestLinkPWA

HTML page as the starting point of a Progressive Web Application, linked to a manifest.json file for application configuration.

How to open:
Open this folder in Visual Studio Code (File > Open Folder), then open index.html in a browser, or use the Live Server extension. The Service Worker needs to be served over localhost or https to install.
