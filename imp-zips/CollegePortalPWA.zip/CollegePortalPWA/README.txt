CollegePortalPWA

College Information Portal website converted into a Progressive Web Application by implementing a Service Worker and Web App Manifest.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
