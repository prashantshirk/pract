using Microsoft.AspNetCore.Mvc;

namespace CollegePortalPWA.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() { return View(); }
    }
}
