InterfaceArea

Create an interface containing a method to calculate area. Implement it in Circle and Rectangle classes and display their areas.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
