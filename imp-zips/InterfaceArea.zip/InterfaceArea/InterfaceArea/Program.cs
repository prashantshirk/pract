using System;

namespace InterfaceArea
{
    interface IShape
    {
        double Area();
    }

    class Circle : IShape
    {
        public double Radius { get; set; }
        public Circle(double radius) { Radius = radius; }
        public double Area() { return Math.PI * Radius * Radius; }
    }

    class Rectangle : IShape
    {
        public double Length { get; set; }
        public double Breadth { get; set; }
        public Rectangle(double length, double breadth) { Length = length; Breadth = breadth; }
        public double Area() { return Length * Breadth; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IShape circle = new Circle(5);
            IShape rectangle = new Rectangle(4, 6);
            Console.WriteLine("Area of Circle: " + circle.Area());
            Console.WriteLine("Area of Rectangle: " + rectangle.Area());
            Console.ReadLine();
        }
    }
}
