PWAOfflinePage

PWA that displays a custom offline page whenever the user loses internet connectivity, using a Service Worker to cache resources.

How to open:
Open this folder in Visual Studio Code (File > Open Folder), then open index.html in a browser, or use the Live Server extension. The Service Worker needs to be served over localhost or https to install.
