const CACHE_NAME = 'offline-page-v1';
self.addEventListener('install', event => {
    event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(['index.html', 'offline.html', 'style.css', 'app.js'])));
});
self.addEventListener('fetch', event => {
    event.respondWith(fetch(event.request).catch(() => caches.match('offline.html')));
});
