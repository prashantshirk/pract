using Microsoft.AspNetCore.Mvc;

namespace FactorialApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MathController : ControllerBase
    {
        // GET api/math/factorial/5  ->  120
        // Test in Postman with GET http://localhost:5000/api/math/factorial/5
        [HttpGet("factorial/{number}")]
        public IActionResult Factorial(int number)
        {
            if (number < 0) return BadRequest("Number must not be negative.");
            long result = 1;
            for (int i = 2; i <= number; i++) result *= i;
            return Ok(new { number = number, factorial = result });
        }
    }
}
