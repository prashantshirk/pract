FactorialApi

ASP.NET Core Web API endpoint that accepts a number and returns its factorial. Test it in Postman with valid inputs.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
