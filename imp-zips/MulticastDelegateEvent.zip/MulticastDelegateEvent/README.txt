MulticastDelegateEvent

C# program demonstrating a multicast delegate that invokes multiple methods, and an event with a suitable example.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
