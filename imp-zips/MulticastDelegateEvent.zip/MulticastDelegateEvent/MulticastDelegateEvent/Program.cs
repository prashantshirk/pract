using System;

namespace MulticastDelegateEvent
{
    public delegate void Notify(string message);

    class Publisher
    {
        public event Notify OnNotify;

        public void Raise(string message)
        {
            if (OnNotify != null) OnNotify(message);
        }
    }

    class Program
    {
        static void ShowMessage(string message) { Console.WriteLine("Message: " + message); }
        static void ShowUpper(string message) { Console.WriteLine("Upper: " + message.ToUpper()); }

        static void Main(string[] args)
        {
            // Multicast delegate: one delegate invokes multiple methods
            Notify multi = ShowMessage;
            multi += ShowUpper;
            multi("Hello from multicast delegate");

            // Event example
            Publisher publisher = new Publisher();
            publisher.OnNotify += ShowMessage;
            publisher.OnNotify += ShowUpper;
            publisher.Raise("Hello from event");
            Console.ReadLine();
        }
    }
}
