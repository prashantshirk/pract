<%@ Application Codebehind="Global.asax.cs" Inherits="EmployeeRegistrationValidators.Global" Language="C#" %>
