using System.Web.UI.WebControls;
namespace EmployeeRegistrationValidators
{
    public partial class EmployeeRegistration
    {
        protected global::System.Web.UI.WebControls.Label lblName;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvName;
        protected global::System.Web.UI.WebControls.Label lblAge;
        protected global::System.Web.UI.WebControls.TextBox txtAge;
        protected global::System.Web.UI.WebControls.RangeValidator rvAge;
        protected global::System.Web.UI.WebControls.Label lblEmail;
        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        protected global::System.Web.UI.WebControls.RegularExpressionValidator revEmail;
        protected global::System.Web.UI.WebControls.Label lblPassword;
        protected global::System.Web.UI.WebControls.TextBox txtPassword;
        protected global::System.Web.UI.WebControls.Label lblConfirm;
        protected global::System.Web.UI.WebControls.TextBox txtConfirm;
        protected global::System.Web.UI.WebControls.CompareValidator cvPassword;
        protected global::System.Web.UI.WebControls.Button btnRegister;
        protected global::System.Web.UI.WebControls.Label lblOutput;
    }
}
