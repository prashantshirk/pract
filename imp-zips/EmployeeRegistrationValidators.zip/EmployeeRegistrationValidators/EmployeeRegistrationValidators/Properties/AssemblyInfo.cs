using System.Reflection;
[assembly: AssemblyTitle("EmployeeRegistrationValidators")]
[assembly: AssemblyVersion("1.0.0.0")]
