using System;
using System.Web.UI;

namespace EmployeeRegistrationValidators
{
    public partial class EmployeeRegistration : Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                lblOutput.Text = "Employee registration successful for " + txtName.Text;
            }
        }
    }
}
