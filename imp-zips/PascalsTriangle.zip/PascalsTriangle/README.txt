PascalsTriangle

C# program that accepts the number of rows and displays Pascal's triangle using nested loops.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
