using System;

namespace PascalsTriangle
{
    class Program
    {
        static int Factorial(int n)
        {
            int result = 1;
            for (int i = 2; i <= n; i++) result *= i;
            return result;
        }

        static void Main(string[] args)
        {
            Console.Write("Enter number of rows: ");
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n - i - 1; j++) Console.Write(" ");
                for (int j = 0; j <= i; j++)
                {
                    int value = Factorial(i) / (Factorial(j) * Factorial(i - j));
                    Console.Write(value + " ");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
