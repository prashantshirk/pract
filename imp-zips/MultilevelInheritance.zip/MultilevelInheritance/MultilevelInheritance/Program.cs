using System;

namespace MultilevelInheritance
{
    class GrandParent
    {
        public void ShowGrandParent() { Console.WriteLine("I am the grandparent."); }
    }

    class Parent : GrandParent
    {
        public void ShowParent() { Console.WriteLine("I am the parent."); }
    }

    class Child : Parent
    {
        public void ShowChild() { Console.WriteLine("I am the child."); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Child child = new Child();
            child.ShowGrandParent();
            child.ShowParent();
            child.ShowChild();
            Console.ReadLine();
        }
    }
}
