MultilevelInheritance

C# program demonstrating multilevel inheritance with suitable examples.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
