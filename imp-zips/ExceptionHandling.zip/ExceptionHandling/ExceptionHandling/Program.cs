using System;

namespace ExceptionHandling
{
    class AgeException : Exception
    {
        public AgeException(string message) : base(message) { }
    }

    class Program
    {
        static void CheckAge(int age)
        {
            if (age < 18) throw new AgeException("Age must be 18 or above.");
            Console.WriteLine("Age is valid.");
        }

        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter age: ");
                int age = Convert.ToInt32(Console.ReadLine());
                CheckAge(age);
                int result = 100 / age;
                Console.WriteLine("100 / age = " + result);
            }
            catch (AgeException ex)
            {
                Console.WriteLine("Custom exception: " + ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Format exception: Please enter a number. " + ex.Message);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Divide by zero exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("General exception: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Finally block always executes.");
            }
            Console.ReadLine();
        }
    }
}
