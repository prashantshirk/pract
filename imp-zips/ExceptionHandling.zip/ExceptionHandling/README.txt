ExceptionHandling

C# program demonstrating exception handling using try-catch-finally blocks, custom exceptions and multiple catch handlers.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
