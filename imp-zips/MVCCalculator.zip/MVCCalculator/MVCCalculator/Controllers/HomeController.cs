using Microsoft.AspNetCore.Mvc;
using MVCCalculator.Models;

namespace MVCCalculator.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() { return View(new Calculator()); }

        [HttpPost]
        public IActionResult Index(Calculator model, string operation)
        {
            if (operation == "Add") model.Result = model.Number1 + model.Number2;
            else if (operation == "Subtract") model.Result = model.Number1 - model.Number2;
            else if (operation == "Multiply") model.Result = model.Number1 * model.Number2;
            else if (operation == "Divide" && model.Number2 != 0) model.Result = model.Number1 / model.Number2;
            return View(model);
        }
    }
}
