using System.Reflection;
[assembly: AssemblyTitle("StudentRegistrationValidation")]
[assembly: AssemblyVersion("1.0.0.0")]
