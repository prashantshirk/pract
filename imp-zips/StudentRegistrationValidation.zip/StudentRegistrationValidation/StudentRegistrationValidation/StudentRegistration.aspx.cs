using System;
using System.Web.UI;

namespace StudentRegistrationValidation
{
    public partial class StudentRegistration : Page
    {
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                lblOutput.Text = "Name: " + txtName.Text + "<br/>Age: " + txtAge.Text
                    + "<br/>Email: " + txtEmail.Text + "<br/>Course: " + ddlCourse.SelectedValue;
            }
        }
    }
}
