<%@ Application Codebehind="Global.asax.cs" Inherits="StudentRegistrationValidation.Global" Language="C#" %>
