using System.Web.UI.WebControls;
namespace StudentRegistrationValidation
{
    public partial class StudentRegistration
    {
        protected global::System.Web.UI.WebControls.Label lblName;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvName;
        protected global::System.Web.UI.WebControls.Label lblAge;
        protected global::System.Web.UI.WebControls.TextBox txtAge;
        protected global::System.Web.UI.WebControls.RangeValidator rvAge;
        protected global::System.Web.UI.WebControls.Label lblEmail;
        protected global::System.Web.UI.WebControls.TextBox txtEmail;
        protected global::System.Web.UI.WebControls.RegularExpressionValidator revEmail;
        protected global::System.Web.UI.WebControls.Label lblCourse;
        protected global::System.Web.UI.WebControls.DropDownList ddlCourse;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.Label lblOutput;
    }
}
