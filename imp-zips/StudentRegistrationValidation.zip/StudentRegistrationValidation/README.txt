StudentRegistrationValidation

ASP.NET Web Forms program to validate student registration details and display the submitted information using appropriate controls.

How to open:
Open the solution file in Visual Studio, restore NuGet packages if asked, then run with IIS Express. The folder can also be opened in Visual Studio Code to read the .aspx and .aspx.cs files.
