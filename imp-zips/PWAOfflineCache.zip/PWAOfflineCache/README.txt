PWAOfflineCache

PWA that caches HTML, CSS, JavaScript and image files using a Service Worker, so it works without an internet connection.

How to open:
Open this folder in Visual Studio Code (File > Open Folder), then open index.html in a browser, or use the Live Server extension. The Service Worker needs to be served over localhost or https to install.
