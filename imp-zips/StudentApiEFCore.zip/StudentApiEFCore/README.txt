StudentApiEFCore

ASP.NET Core Web API that performs Create, Read, Update and Delete on student records stored in a database using Entity Framework Core.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
