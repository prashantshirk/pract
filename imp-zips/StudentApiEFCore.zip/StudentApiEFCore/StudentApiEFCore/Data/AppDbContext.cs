using Microsoft.EntityFrameworkCore;
using StudentApiEFCore.Models;

namespace StudentApiEFCore.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Student> Students { get; set; }
    }
}
