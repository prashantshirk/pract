using System;

namespace MultipleInheritanceInterfaces
{
    interface IWalk
    {
        void Walk();
    }

    interface ISwim
    {
        void Swim();
    }

    // C# does not allow multiple class inheritance, but a class
    // can implement multiple interfaces. This is how multiple
    // inheritance is achieved in C#.
    class Person : IWalk, ISwim
    {
        public void Walk() { Console.WriteLine("Person is walking."); }
        public void Swim() { Console.WriteLine("Person is swimming."); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Walk();
            person.Swim();
            Console.ReadLine();
        }
    }
}
