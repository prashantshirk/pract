using System;

namespace SortedCities
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cities = new string[10];
            Console.WriteLine("Enter names of 10 cities:");
            for (int i = 0; i < cities.Length; i++)
            {
                cities[i] = Console.ReadLine();
            }
            Array.Sort(cities);
            Console.WriteLine("Cities in alphabetical order:");
            foreach (string city in cities)
            {
                Console.WriteLine(city);
            }
            Console.ReadLine();
        }
    }
}
