SortedCities

C# program that accepts the names of ten cities and displays them in alphabetical order.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
