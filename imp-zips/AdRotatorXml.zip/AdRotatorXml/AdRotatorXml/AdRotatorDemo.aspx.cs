using System;
using System.Web.UI;

namespace AdRotatorXml
{
    public partial class AdRotatorDemo : Page
    {
    }
}
