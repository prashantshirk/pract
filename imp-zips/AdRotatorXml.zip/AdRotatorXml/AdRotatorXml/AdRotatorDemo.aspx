<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AdRotatorDemo.aspx.cs" Inherits="AdRotatorXml.AdRotatorDemo" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server"><title>AdRotator Demo</title></head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:AdRotator ID="adRotator" runat="server" AdvertisementFile="~/Ads.xml" />
        </div>
    </form>
</body>
</html>
