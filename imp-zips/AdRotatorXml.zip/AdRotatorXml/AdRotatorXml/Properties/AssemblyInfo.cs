using System.Reflection;
[assembly: AssemblyTitle("AdRotatorXml")]
[assembly: AssemblyVersion("1.0.0.0")]
