using System.Web.UI.WebControls;
namespace AdRotatorXml
{
    public partial class AdRotatorDemo
    {
        protected global::System.Web.UI.WebControls.AdRotator adRotator;
    }
}
