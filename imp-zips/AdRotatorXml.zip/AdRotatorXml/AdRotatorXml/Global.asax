<%@ Application Codebehind="Global.asax.cs" Inherits="AdRotatorXml.Global" Language="C#" %>
