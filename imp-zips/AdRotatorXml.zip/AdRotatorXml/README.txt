AdRotatorXml

ASP.NET Web Forms program demonstrating the AdRotator control to display rotating advertisements from an XML file.

How to open:
Open the solution file in Visual Studio, restore NuGet packages if asked, then run with IIS Express. The folder can also be opened in Visual Studio Code to read the .aspx and .aspx.cs files.
