using Microsoft.AspNetCore.Mvc;

namespace SessionPersistentCookiesCore.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.SessionValue = HttpContext.Session.GetString("UserName");
            ViewBag.CookieValue = Request.Cookies["UserName"];
            return View();
        }

        [HttpPost]
        public IActionResult Save(string userName)
        {
            // Session cookie: lives only until the browser / session ends
            HttpContext.Session.SetString("UserName", userName);
            // Persistent cookie: stored for 30 days, even after the browser closes
            Response.Cookies.Append("UserName", userName, new CookieOptions
            {
                Expires = DateTime.Now.AddDays(30),
                HttpOnly = true
            });
            return RedirectToAction("Index");
        }
    }
}
