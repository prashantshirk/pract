SessionPersistentCookiesCore

ASP.NET Core web application demonstrating session cookies and persistent cookies.

How to open:
Open this folder in Visual Studio Code, or open the .sln file in Visual Studio, then run the project (dotnet run for console and ASP.NET Core projects).
