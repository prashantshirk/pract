<%@ Application Codebehind="Global.asax.cs" Inherits="RegistrationFormValidators.Global" Language="C#" %>
