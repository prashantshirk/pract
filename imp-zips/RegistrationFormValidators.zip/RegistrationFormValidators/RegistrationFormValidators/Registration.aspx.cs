using System;
using System.Web.UI;

namespace RegistrationFormValidators
{
    public partial class Registration : Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                lblOutput.Text = "Registration successful for " + txtName.Text;
            }
        }
    }
}
