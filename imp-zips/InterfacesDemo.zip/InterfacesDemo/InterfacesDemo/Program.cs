using System;

namespace InterfacesDemo
{
    interface IDrawable
    {
        void Draw();
    }

    interface IPrintable
    {
        void Print();
    }

    class Document : IDrawable, IPrintable
    {
        public void Draw() { Console.WriteLine("Document is drawn."); }
        public void Print() { Console.WriteLine("Document is printed."); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IDrawable drawable = new Document();
            IPrintable printable = new Document();
            drawable.Draw();
            printable.Print();
            Console.ReadLine();
        }
    }
}
