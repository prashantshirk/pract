using System.Web.UI.WebControls;
namespace StudentRegistrationForm
{
    public partial class StudentForm
    {
        protected global::System.Web.UI.WebControls.Label lblName;
        protected global::System.Web.UI.WebControls.TextBox txtName;
        protected global::System.Web.UI.WebControls.Label lblGender;
        protected global::System.Web.UI.WebControls.RadioButton rdoMale;
        protected global::System.Web.UI.WebControls.RadioButton rdoFemale;
        protected global::System.Web.UI.WebControls.Label lblCourse;
        protected global::System.Web.UI.WebControls.DropDownList ddlCourse;
        protected global::System.Web.UI.WebControls.CheckBox chkTerms;
        protected global::System.Web.UI.WebControls.Label lblDate;
        protected global::System.Web.UI.WebControls.Calendar calDob;
        protected global::System.Web.UI.WebControls.Button btnSubmit;
        protected global::System.Web.UI.WebControls.Label lblOutput;
    }
}
