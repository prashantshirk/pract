using System.Reflection;
[assembly: AssemblyTitle("StudentRegistrationForm")]
[assembly: AssemblyVersion("1.0.0.0")]
