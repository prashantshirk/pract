using System;
using System.Web.UI;

namespace StudentRegistrationForm
{
    public partial class StudentForm : Page
    {
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string gender = rdoMale.Checked ? "Male" : "Female";
            lblOutput.Text = "Name: " + txtName.Text + "<br/>Gender: " + gender
                + "<br/>Course: " + ddlCourse.SelectedValue
                + "<br/>Terms accepted: " + chkTerms.Checked
                + "<br/>Date of Birth: " + calDob.SelectedDate.ToShortDateString();
        }
    }
}
