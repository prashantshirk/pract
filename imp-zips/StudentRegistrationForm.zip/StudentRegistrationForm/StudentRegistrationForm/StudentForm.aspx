<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="StudentForm.aspx.cs" Inherits="StudentRegistrationForm.StudentForm" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server"><title>Student Registration Form</title></head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:Label ID="lblName" runat="server" Text="Student Name"></asp:Label>
            <asp:TextBox ID="txtName" runat="server"></asp:TextBox>
            <br />
            <asp:Label ID="lblGender" runat="server" Text="Gender"></asp:Label>
            <asp:RadioButton ID="rdoMale" runat="server" Text="Male" GroupName="Gender" />
            <asp:RadioButton ID="rdoFemale" runat="server" Text="Female" GroupName="Gender" />
            <br />
            <asp:Label ID="lblCourse" runat="server" Text="Course"></asp:Label>
            <asp:DropDownList ID="ddlCourse" runat="server">
                <asp:ListItem>BSc IT</asp:ListItem>
                <asp:ListItem>BSc CS</asp:ListItem>
                <asp:ListItem>BCom</asp:ListItem>
            </asp:DropDownList>
            <br />
            <asp:CheckBox ID="chkTerms" runat="server" Text="I accept the terms and conditions" />
            <br />
            <asp:Label ID="lblDate" runat="server" Text="Date of Birth"></asp:Label>
            <asp:Calendar ID="calDob" runat="server"></asp:Calendar>
            <br />
            <asp:Button ID="btnSubmit" runat="server" Text="Submit" OnClick="btnSubmit_Click" />
            <br />
            <asp:Label ID="lblOutput" runat="server" Text=""></asp:Label>
        </div>
    </form>
</body>
</html>
