StudentRegistrationForm

ASP.NET Web Forms Student Registration Form using Label, TextBox, RadioButton, DropDownList, CheckBox, Calendar and Button controls.

How to open:
Open the solution file in Visual Studio, restore NuGet packages if asked, then run with IIS Express. The folder can also be opened in Visual Studio Code to read the .aspx and .aspx.cs files.
