﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="CookiesDemo.aspx.cs" Inherits="Cookies.CookiesDemo" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="height: 318px">
            <asp:Label ID="username" runat="server" Text="User Name "></asp:Label>
            <asp:TextBox ID="txtusername" runat="server"></asp:TextBox>
            <br />
            <asp:Button ID="Savebtn" runat="server" OnClick="Savebtn_Click" Text="Save Button" />
            <br />
            <br />
            <asp:Button ID="Showbtn" runat="server" OnClick="Showbtn_Click" Text="Show Button" />
            <br />
            <br />
            <asp:Label ID="output" runat="server" Text="output"></asp:Label>
            <br />
        </div>
    </form>
</body>
</html>
