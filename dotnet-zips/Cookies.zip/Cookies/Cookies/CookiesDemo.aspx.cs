﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cookies
{
    public partial class CookiesDemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Savebtn_Click(object sender, EventArgs e)
        {
            HttpCookie sessionCookie = new HttpCookie("sessionCookie");
            sessionCookie.Value = txtusername.Text;
            Response.Cookies.Add(sessionCookie);
            HttpCookie persistentCookie = new HttpCookie("PersistentCookies");
            persistentCookie.Value = txtusername.Text;
            persistentCookie.Expires = DateTime.Now.AddDays(30);
            persistentCookie.HttpOnly = true;
            Response.Cookies.Add(persistentCookie);
            output.Text = "Cookies saved successfully!";
        }


        protected void Showbtn_Click(object sender, EventArgs e)
        {
            string sessionCookies = Request.Cookies["sessionCookie"].Value;
            string persistentcookies = Request.Cookies["PersistentCookies"].Value;
            output.Text = "session data " + sessionCookies + "persistent data" + persistentcookies;
        }
    }
}