﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    interface IShape {
        void shape();
    }
    class Circle : IShape
    {
        public void shape()
        {
            int x = 5;
            Console.WriteLine("Circle  " + x * x);
        }
    }
     

    internal class Program
    {
        static void Main(string[] args)
        {
            Circle c = new Circle();
            c.shape();

        }
    }
}
