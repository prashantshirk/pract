﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionOverloadings
{

    class overloadings { 
    
        public void add(int a, int b)
        {
            Console.WriteLine("Sum of two integers: " + (a + b));
        }
        public void add(int a , int b ,int c)
        {
            Console.WriteLine("Sum of three integers: " + (a + b + c));
        }
        public void add(double a,double b ,double c)
        {
            Console.WriteLine("Sum of three doubles: " + (a + b + c));
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            overloadings over = new overloadings();
            over.add(45, 54);
            over.add(3434, 434, 433);
            over.add(34.5, 45.6, 56.7);
        }
    }
}
