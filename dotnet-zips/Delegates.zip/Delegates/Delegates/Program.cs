﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    public delegate void calculations(int a , int b);

    public class methodsofCalculator { 
        public void add(int a, int b)
        {
            Console.WriteLine("Addition of two numbers is: " + (a + b));
        }
        public void sub(int a, int b)
        {
            Console.WriteLine("Subtraction of two numbers is: " + (a - b));
        }
        public void mul(int a, int b)
        {
            Console.WriteLine("Multiplication of two numbers is: " + (a * b));
        }
        public void div(int a ,int b)
        {
            Console.WriteLine("Division of two numbers is: " + (a / b));
        }
    }


internal class Program
    {
        static void Main(string[] args)
        {
            methodsofCalculator obj = new methodsofCalculator();
            calculations c;
            c = obj.add;
            c(4, 34);
            c = obj.sub;
            c(45, 45);
            c = obj.mul;
            c(424, 3434);
            c = obj.div;
            c(4234, 424);
               
        }
    }
}
