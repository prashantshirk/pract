﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Adrotator.Global" Language="C#" %>
