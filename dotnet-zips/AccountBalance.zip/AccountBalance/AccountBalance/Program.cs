﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountBalance
{
    internal class Program
    {
        private double balance;
            public int Accountnumber { get; set; }
        public double Balance
        {
            get
            {
                return balance;
            }
            set
            {
            if(value <0)
            {
                throw new ArgumentException("Balance cannot be negative.");
            }
            else
            {
                balance = value;
            }
        }
    }

    
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Accountnumber = 32323223;
            p.Balance = -43434243;
            Console.WriteLine("Account Number: " + p.Accountnumber);
            Console.WriteLine("Balance: " + p.balance);
        }
    }
}
