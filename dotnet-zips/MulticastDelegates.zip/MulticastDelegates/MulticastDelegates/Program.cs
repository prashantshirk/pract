﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticastDelegates
{
    public delegate void methoddss();
    class programm
    {
     public void method1()
        {
            Console.WriteLine("This is method 1");
        }
        public void display()
        {
            Console.WriteLine("This is method 2");

        }
        public void print()
        {
            Console.WriteLine("This is method 3");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            programm p = new programm();
            methoddss m;
            m = p.method1;
            m += p.display;
            m += p.print;
            m();
            Console.ReadLine();

        }
    }
}
