using calc.Models;
using Microsoft.AspNetCore.Mvc;
namespace calc.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
       public  IActionResult Index(Caclculator calc)
        {
            switch (calc.operation)
            {
                case "+":
                    calc.result = calc.number1 + calc.number2;
                    break;
                case "-":
                    calc.result = calc.number1 - calc.number2;
                    break;
                case "*":
                    calc.result = calc.number1 * calc.number2;
                    break;
                case "/":
                    if(calc.number2 != 0)
                    {
                        calc.result = calc.number1 / calc.number2;

                    }
                    break;
            }
            return View(calc);
        }

    }
}
