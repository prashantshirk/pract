﻿namespace calc.Models
{
    public class Caclculator
    {
        public double number1 { get; set; }
        public double number2 { get; set; }
        public string operation { get; set; }

        public double result{ get; set; }

    }
}
