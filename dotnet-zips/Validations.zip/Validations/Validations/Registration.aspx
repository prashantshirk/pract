﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Registration.aspx.cs" Inherits="Validations.Registration" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="height: 521px">
            <asp:Label ID="name" runat="server" ClientIDMode="Predictable" Text="Name"></asp:Label>
            <asp:TextBox ID="txtname" runat="server" OnTextChanged="txtname_TextChanged"></asp:TextBox>
            <br />
            <br />
            <asp:Label ID="email" runat="server" Text="email"></asp:Label>
&nbsp;<asp:TextBox ID="txtemail" runat="server" ValidationGroup="txtemail"></asp:TextBox>
            <br />
            <asp:Label runat="server" Text="Age"></asp:Label>
            <asp:TextBox ID="age" runat="server" MaxLength="60"></asp:TextBox>
            <br />
            <br />
            <asp:Label runat="server" Text="password"></asp:Label>
            <asp:TextBox ID="password" runat="server"></asp:TextBox>
            <br />
            <br />
            <asp:Label ID="Label1" runat="server" Text="Comfirm Password"></asp:Label>
            <asp:TextBox ID="cmfpassword" runat="server"></asp:TextBox>
            <br />
            <br />
            <asp:Button ID="registor" runat="server" OnClick="registor_Click" Text="Button" />
            <br />
            <br />
            <asp:Label ID="output" runat="server" Text="output"></asp:Label>
            <br />
            <br />
            <asp:RegularExpressionValidator runat="server" ControlToValidate="txtemail" ErrorMessage="Invalid Email" ValidationExpression="^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"></asp:RegularExpressionValidator>
            <br />
            <br />
            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtname" ErrorMessage="Name field is required"></asp:RequiredFieldValidator>
            <br />
            <asp:CompareValidator ID="CompareValidator1" runat="server" ControlToCompare="password" ControlToValidate="cmfpassword" ErrorMessage="password isnt macthing"></asp:CompareValidator>
            <asp:RangeValidator ID="RangeValidator1" runat="server" ControlToValidate="age" ErrorMessage="Invalid range" MaximumValue="60" MinimumValue="18" Type="Integer"></asp:RangeValidator>
        </div>
    </form>
</body>
</html>
