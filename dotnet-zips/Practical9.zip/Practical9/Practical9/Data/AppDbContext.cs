﻿    using Microsoft.EntityFrameworkCore;
    using Practical9.Models;
namespace Practical9.Data
{

    namespace StudentAPI.Data
    {
        public class AppDbContext : DbContext
        {
            public AppDbContext(DbContextOptions<AppDbContext> options)
                : base(options)
            {
            }

            public DbSet<Student> Students { get; set; }
        }
    }
}
