﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedCities
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String[] cities =  new String[10];

            for (int i = 0; i < cities.Length; i++)
            {
                cities[i] = Console.ReadLine();
            }

            Array.Sort(cities);
            Console.WriteLine("Sorted cities:"); 
            for (int i = 0; i < cities.Length; i++)
            {
                Console.WriteLine(cities[i]);
            }
        }
    }
}
