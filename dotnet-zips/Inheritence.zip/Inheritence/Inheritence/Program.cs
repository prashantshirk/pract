﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritence
{
    class parent
    {
        public void display()
        {
            Console.Write("Iam the parent classs");
        }
    }

    class firstchild : parent { 
    public void display()
        {
            Console.WriteLine("Iam the first child");
        }
    }

    class secondchild : firstchild
    {
        public void display()
        {
            Console.WriteLine("Iam the muti level child");
        }
    }
    class thirthchild : parent
    {
        public void dislay()
        {
            Console.WriteLine("Iam the thirth child");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            parent p = new parent();
            p.display();
            firstchild f = new firstchild();
            f.display();
            secondchild s = new secondchild();
            s.display();
            thirthchild t = new thirthchild();
            t.dislay();
            Console.ReadLine();
        }
    }
}
