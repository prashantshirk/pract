﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="StudentForm.aspx.cs" Inherits="Courses.StudentForm" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div id="studentname">
            <br />
            Student Name :
            <br />
            <asp:TextBox ID="txtName" runat="server" Height="29px" OnTextChanged="TextBox1_TextChanged" Width="201px"></asp:TextBox>
            <br />
            Gender : <asp:RadioButton ID="male" runat="server" Text="male" />
            <asp:RadioButton ID="Female" runat="server" OnCheckedChanged="Female_CheckedChanged" Text="female" />
            <br />
            Courses :
            <asp:DropDownList ID="courses" runat="server">
                <asp:ListItem>BSCIT</asp:ListItem>
                <asp:ListItem>BSCCS</asp:ListItem>
                <asp:ListItem>BTECH</asp:ListItem>
                <asp:ListItem>Engineering</asp:ListItem>
            </asp:DropDownList>
            <br />
            <br />
            <asp:CheckBox ID="terms" runat="server" Text="I accept terms and Conditions" />
            <br />
            <asp:Calendar ID="date" runat="server"></asp:Calendar>
            <br />
            <br />
            <asp:Button ID="btnSubmit" runat="server" OnClick="btnSubmit_Click" Text="Submit" />
            <br />
            <br />
            <asp:Label ID="output" runat="server"></asp:Label>
            <br />
            <br />
        </div>
    </form>
</body>
</html>
