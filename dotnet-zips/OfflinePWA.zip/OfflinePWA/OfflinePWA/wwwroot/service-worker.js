﻿const CACHE_NAME = 'Offline_cache_v1';

const cacheUrls = [
    "/",
    "~/Offline.html"
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                return cache.addAll(cacheUrls);
            })
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        fetch(event.request)
            .catch(() => {
                return caches.match("~/Offline.html");
            })
    );
});