﻿const cache_name = "PWA_OFFLINE_V1";

const cacheURLToStore = [
    "/",
"/Home/Index",
];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(cache_name)
            .then((cache) => { return cache.addAll(cacheURLToStore)})
    )
})

self.addEventListener("fetch", (event) => {
    event.respondWith(
        caches.match(event.request)
            .then((response) => { return response || event.request })
    )
})