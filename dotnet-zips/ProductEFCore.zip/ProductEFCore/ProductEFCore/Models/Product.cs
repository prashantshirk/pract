﻿namespace ProductEFCore.Models
{
    public class Product
    {
        public int Id { get; set; }
        public required string productName { get; set; }
        public double price { get; set; }
    }
}
