﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{

    class student
    {
        public student()
        {
            Console.WriteLine("Default Constructor");
        }
        public student(int id , String Name)
        {
            Console.WriteLine("Parameterized Constructor" + id + " " + Name);
        }
        public student(int rollNO , String name , int age)
        {
            Console.WriteLine("Parameterized Constructor v2" + rollNO + " " + name);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            student s = new student();
            student sv2 = new student(1, "Anant");
            student sv3 = new student(351, "Anant", 20);
        }
    }
}
